# Gold Scalping Strategy — Backtest First

This is deliberately **offline and disconnected from any live account**.
The goal: find out honestly whether the EMA9/EMA21 + RSI scalping strategy
has any real edge on gold, using real historical prices, before ever
touching a demo account.

## Setup

1. Sign up free at twelvedata.com (email only, no verification).
2. Copy your API key.
3. `pip install -r requirements.txt`
4. Run:
   ```
   TWELVEDATA_API_KEY=your_key_here python fetch_historical_data.py
   ```
   This pulls ~3 months of 5-minute XAU/USD candles into `data/XAUUSD_5min_history.csv`.
   Takes a few minutes due to rate-limit pauses between requests — that's normal.

5. Run the backtest against that data:
   ```
   python backtest.py data/XAUUSD_5min_history.csv
   ```

You'll get a report like:
```
Total trades:       47
Win rate:           38.3% (18W / 29L)
Total pips:         -125.0
Profit factor:      0.71
Max drawdown:       210.0 pips
```

## Reading the results honestly

- **Profit factor below 1.0** means the strategy loses money on this data,
  full stop — even before real-world slippage, which is usually worse than
  backtest assumptions. Don't proceed to demo testing with a losing
  configuration; tune parameters or try a different approach.
- **Win rate isn't the whole story.** A strategy can win 40% of trades and
  still be profitable if wins are bigger than losses (or vice versa) — look
  at profit factor and total pips together.
- **Small trade counts are unreliable.** Under ~30-50 trades, you're
  looking at noise more than signal. Pull more months of history if the
  strategy doesn't fire often enough.
- **The spread assumption matters enormously for gold.** Default is 15
  pips ($1.50), which is realistic-to-conservative for XAUUSD. If you use a
  much tighter assumption, you're not testing something you can actually
  replicate live — you're testing a fantasy.

## Tuning

All strategy parameters are environment variables, so you can experiment
without touching code:

```
SPREAD_PIPS=20 TP_PIPS=20 SL_PIPS=15 python backtest.py data/XAUUSD_5min_history.csv
```

| Variable | Meaning | Default |
|---|---|---|
| `SPREAD_PIPS` | Simulated cost per trade | 15 |
| `PIP_SIZE` | Price movement = 1 pip | 0.1 (gold) |
| `TP_PIPS` | Take-profit distance | 15 |
| `SL_PIPS` | Stop-loss distance | 10 |
| `EMA_FAST` / `EMA_SLOW` | Crossover periods | 9 / 21 |
| `RSI_PERIOD` | RSI lookback | 14 |

Try a handful of combinations, keep notes on what you tried and the
resulting profit factor / win rate, and don't just keep tuning until one
combination looks good on this exact dataset — that's overfitting to
history, not finding a real edge. A good sign is a strategy that's
*reasonably* profitable across several different parameter choices, not
spectacularly profitable at exactly one specific combination.

## What "backtest looks good" should mean before moving to demo

- Profit factor meaningfully above 1.0 (not 1.01 — look for real margin)
- At least 50-100 trades in the sample
- Reasonably consistent across a couple of different 1-month sub-periods
  (split the CSV and re-run, rather than just one big blended number)
- Max drawdown you'd actually be comfortable sitting through

Only once that holds up do we move to forward-testing on the Headway demo
account, where real-time conditions (actual spread behavior, slippage,
news volatility) get to prove or disprove the backtest.
