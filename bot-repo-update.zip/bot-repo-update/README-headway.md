# Headway Scalping Bot (via MetaApi + GitHub Actions)

A small EMA/RSI scalping bot for a Headway MT4/MT5 account, run entirely on
GitHub Actions -- no server needed. Trades are placed through
[MetaApi](https://metaapi.cloud), which is free for one linked MetaTrader
account.

## Read this first

- Your $1 balance leaves **no margin for error**. One losing trade, or even
  overnight swap fees, can wipe it out entirely.
- This bot does **not** guarantee profit of any amount per day. Scalping
  strategies lose money often -- spreads and slippage eat into small-margin
  trades. Treat this as a learning project, not an income source.
- If Headway offers a demo account, test there first before connecting a
  real-money Cent account.
- I'm not a financial advisor and this isn't financial advice -- you're
  responsible for whatever this bot does with your money.

## Step 1: Get your Headway MT4/MT5 login details

You'll need the three things MetaTrader itself needs:
- **Login** (your account number)
- **Password** (your *trading* password, not your Headway web login password)
- **Server name** (e.g. `Headway-Live` or `Headway-Demo` -- shown in your
  Headway account details / welcome email)

## Step 2: Create a MetaApi account and link Headway

1. Go to https://app.metaapi.cloud and sign up (free).
2. In the dashboard, add a new MetaTrader account -- enter the login,
   password, and server name from Step 1.
3. Wait for it to show as **deployed** and **connected** (can take a couple
   of minutes).
4. Copy the **Account ID** shown for this account.
5. Go to https://app.metaapi.cloud/token and generate an API token. Copy it.

## Step 3: Create your GitHub repo and add the files

1. Create a new repo on GitHub (or use an existing one).
2. Upload these files, keeping the folder structure exactly as-is:
   ```
   requirements.txt
   test_connection.py
   trading_bot.py
   .github/workflows/trading-bot.yml
   .github/workflows/test-connection.yml
   ```

## Step 4: Add your secrets

In your repo: **Settings → Secrets and variables → Actions → New repository secret**

Add two secrets:
- `METAAPI_TOKEN` -- the token from Step 2.5
- `METAAPI_ACCOUNT_ID` -- the account ID from Step 2.4

## Step 5: Test the connection

Go to the **Actions** tab → **Test MetaApi Connection** → **Run workflow**.

Check the logs. You should see your account balance and currency printed. If
it fails, the error message will usually tell you what's wrong (bad token,
wrong account ID, account not deployed yet).

## Step 6: Enable the live bot

Once the test passes, go to **Actions** → **Headway Scalping Bot** → **Run
workflow** to try it manually once. If that runs cleanly, the `cron` schedule
in `trading-bot.yml` will then run it automatically every 15 minutes.

Every run appends a line to `trades.csv` in your repo (committed
automatically) so you can watch what the bot is doing over time.

## Tuning the strategy

All of this lives in the `env:` block of `trading-bot.yml` -- edit and
commit to change behavior without touching the Python:

| Variable | Meaning | Default |
|---|---|---|
| `SYMBOL` | Currency pair to trade | `EURUSD` |
| `LOT_SIZE` | Position size per trade | `0.01` (usually the minimum) |
| `TAKE_PROFIT_PIPS` | Profit target per trade | `5` |
| `STOP_LOSS_PIPS` | Max loss per trade | `3` |
| `TIMEFRAME` | Candle timeframe | `5m` |

The entry logic itself (EMA9/EMA21 crossover + RSI filter) is in
`trading_bot.py` if you want to change the strategy entirely.

## Turning it off

Delete or comment out the `schedule:` block in `trading-bot.yml`, or disable
the workflow from the Actions tab.

## Signal scanner (paper mode — separate from trading_bot.py above)

`signal_scanner.py` is a **different, safer tool** than `trading_bot.py`
above. It never places real orders — it only reads candles/prices and
tracks hypothetical entry/SL/TP outcomes. Use this one for now.

- Scans EURUSD, GBPUSD, USDJPY, and XAUUSD (gold) on M5 candles.
- Same EMA9/EMA21 crossover + RSI(14) filter as before.
- When a signal fires, records entry price + stop-loss + take-profit and
  tracks it as "open."
- Every subsequent run checks whether price has hit TP or SL, and logs the
  outcome (WIN/LOSS) with pips and % move — all hypothetical, no money moves.

**Setup**: add `signal_scanner.py` and
`.github/workflows/signal-scanner.yml` to your repo alongside the existing
files. It reuses the same `METAAPI_TOKEN` / `METAAPI_ACCOUNT_ID` secrets you
already set up — nothing new to configure.

**Important — verify gold's pip size**: `SYMBOL_CONFIG` in
`signal_scanner.py` assumes XAUUSD's pip = $0.10, which is a common but not
universal convention. Check Headway's exact contract specification for
XAUUSD (MT4/5 → right-click the symbol in Market Watch → Specification) and
adjust `pip_size` in the script if it doesn't match.

**Viewing results**: a "Forex Scalp" tab was added to the same dashboard as
the crypto scanner (`docs/index.html`) — same URL as before, just tap the
tab. It shows currently-open signals, win rate, cumulative pips, and a
chart of hypothetical performance over time.

